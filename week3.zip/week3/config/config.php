<?php
    $host = '127.0.0.1';
    $database = 'week3db';
    $user = 'root';
    $password = 'MyStrongPassword88';
?>