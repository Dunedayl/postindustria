<?php
    include_once ("entyti.php");
    
    class Shops extends Entity
    {
        protected $table = "shops";

        //public $id;
        public $name;
        public $domain;

    }
