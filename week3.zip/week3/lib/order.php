<?php
    include_once ("entyti.php");
    
    class Orders extends Entity
    {
        protected static $table = "orders";

        protected $id;
        public $sum;
        public $order_date;
        public $userEmail;
        public $shopDomain;

    }
