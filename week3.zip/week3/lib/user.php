<?php
    include_once ("entyti.php");
    
    class Users extends Entity
    {
        protected static $table = "users";

        protected $id;
        public $firstName;
        public $lastName;
        public $email;

    }

?>