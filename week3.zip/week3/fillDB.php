<?php
    include_once ("../week3/lib/user.php");
    include_once ("../week3/lib/shop.php");
    include_once ("../week3/lib/order.php");
        
    $temp = file_get_contents("purchase_log.json");
    $json = explode("\n", $temp);

    $result = [];

    foreach ($json as $key => &$value) {
        $result[] =  json_decode($value, true);
    }

    $shops = [];
    $users = [];
    $orders = [];
    $products = [];
    $categories = [];
    $shopId = 0;
    $userId = 0;
    $orderId = 0;
    $categoriId = 0; 
    $productId = 0;

    foreach ($result as $key => &$value) {
        $value["id"] = ++$orderId;

        $shops[] = ["Name" => $value["shop_name"], "Domain" => $value["shop_domain"]];
        $users[] = ["FirstName"=> $value["user_first_name"], "LastName"=>$value["user_last_name"], "Email"=>$value["user_email"]];
        $orders[] = ["Sum"=>$value["sum"], "Date"=>$value["date"]];

        foreach ($value["products"] as $key => &$prod) {
            $products[] = ["Name"=>$prod["name"], "Category"=>$prod["product_categories"]];
            $prod["product_categories"] = explode(",", $prod["product_categories"]);
        }
    }

    $uniqShop = array_unique($shops, SORT_REGULAR);




    $uniqUsers = array_unique($users, SORT_REGULAR);

    $uniqProducts = array_unique($products, SORT_REGULAR);

    foreach ($uniqProducts as $key => &$value) {
        $temp = explode(",", $value["Category"]);
        $categories = array_merge($categories, $temp);
        $value["Category"] = $temp;
    }

    $uniqCategories = array_unique($categories, SORT_REGULAR);

    foreach ($uniqShop as $key => &$value) {
        $value["id"] = ++$shopId;
    }



// foreach ($uniqUsers as $key => &$value) {
//     $value["id"] = ++$userId;
// }

// foreach ($result as $key => &$value) {
//     $tempShop = array_search($value["shop_name"], array_column($uniqShop, "Name"));
//     $value["shopId"] = $temp;

//     $tempUser = array_search($value["user_email"], array_column($uniqUsers, "Email"));
//     $value["userId"] = $temp;
// }

// foreach ($uniqProducts as $key => &$value) {
//     $value["id"] = ++$productId;
// }

// foreach ($uniqCategories as $key => &$value) {
//     $value["id"] = ++$categoriId;
// }

    foreach ($uniqProducts as $key => &$prod) {
        $prod["id"] = ++$productId;
        foreach ($prod["Category"] as $key => &$cat) {
            $tempCat = array_search($cat, $uniqCategories);
            $cat = ["id" => $tempCat, "Name" => $cat];
        }
    }




//print_r($result[0]);
    $tata = $uniqShop;

    print_r($tata[5]);

    $insertShops =[];
    foreach ($uniqShop as $key => $value) {
        $shop = new Shops();
        //$shop->id = $value["id"];
        $shop->name = $value["Name"];
        $shop->domain = $value["Domain"];
        $insertShops[] = $shop;
    }

    print_r($tata[5]);

    $insertUsers = [];
    foreach ($uniqUsers as $key => $value) {
        $user = new Users();
        $user->firstName = $value["FirstName"];
        $user->lastName = $value["LastName"];
        $user->email = $value["Email"];
        $insertUsers[] = $user;
    }

    print_r($tata[5]);

    $insertOrders = [];
    foreach ($result as $key => $value) {
        $order = new Orders();
        $order->sum = $value["sum"];
        $order->order_date = $value["date"];
        $order->shopDomain = $value["shop_domain"];
        $order->userEmail = $value["user_email"];
        $insertOrders[] = $order;
    }

    print_r($tata[5]);

    print_r($tata);

    // $shopp = new Shops();
    // $shopp->start();
    // $shopp->saveAll($insertShops);




    // $userr = new Users();
    // $userr->start();
    // $userr->saveAll($insertUsers);

    // $order = new Orders();
    // $order->start();
    // $order->saveAll($insertOrders);

?>